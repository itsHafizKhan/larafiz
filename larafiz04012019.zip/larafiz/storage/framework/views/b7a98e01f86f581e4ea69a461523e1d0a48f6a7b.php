<!DOCTYPE html>
<html>
<head>
	<title>Projects</title>
</head>
<body>
	<h1>Projects</h1>
		<ul>
			<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<a href="/projects/<?php echo e($projects->id); ?>">
						<?php echo e($projects->title); ?>

					</a>
					
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

</body>
</html>