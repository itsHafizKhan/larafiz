<?php $__env->startSection('content'); ?>

	<h1 class="title">Create New Shortened URL</h1>

	<form method="POST" action="/links/">
		<?php echo csrf_field(); ?>

		<div class="columns">
			<div class="column">
				<div class="field">
					<label class="label">
						Long URL
					</label>
					<div class="control">
						<input class="input" type="text" name="long_url" placeholder="Long URL" value="<?php echo e(old('long_url')); ?>"></input>	
					</div>
				</div>
			</div>
			<div class="column">
				<div class="field">
					<label class="label">
						Your Email Address
					</label>
					<div class="control">
						<input class="input" type="text" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>"></input>	
					</div>
				</div>
			</div>
		</div>
		<div class="columns">
			<div class="column">
				<div class="field">
					<label></label>
					<div class="control">
						<button class="button is-link" type="submit">Shortened My URL</button>
					</div>
				</div>
			</div>
		</div>



		<?php if($errors->any()): ?>
            <div class="notification is-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

	</form>
	<?php if($links->isNotEmpty()): ?>
	<div class="columns container">
		<div class="column">
			<table class="table is-bordered">
				<thead>
					<tr>
						<th>Shortened Links</th>
						<th>Original Links</th>
						<th>Owners</th>
						<th>No of Clicks</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><a href="/links/<?php echo e($link->uri_id); ?>" target="_blank"><?php echo e(url('/links/'.$link->uri_id)); ?></a></td>
							<td><?php echo e($link->long_url); ?></td>
							<td><?php echo e($link->email); ?></td>
							<td><?php echo e($link->tracks_count); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>	
	</div>	
	
	<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>