<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                
                    <div class="row">
                        <div class="col-md-6 text-left"><h5><?php echo e(__('Users')); ?></h5></div>
                        <div class="col-md-6 text-right"><a href="<?php echo e(URL::to('admin/users/create')); ?>" class="btn btn-danger">Add New User</a></div>
                    </div> 
            </div>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>    
                    </div>
                    
                <?php endif; ?>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($user->created_at)->format('d-m-Y')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>