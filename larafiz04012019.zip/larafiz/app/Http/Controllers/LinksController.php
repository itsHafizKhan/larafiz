<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Link;
use App\Linkstrack;

class LinksController extends Controller
{
    //
    public function index($id = NULL)
    {
    	
    	if(!empty($id)){
    		//$count = Link::find($id);
    		$long_url = Link::where('uri_id', $id)->first()->long_url;
    		if($long_url !== NULL){
	    	 	$record_id = Link::where('uri_id', $id)->first()->id;
	    	 	$insertLinksTrack = new Linkstrack();
	    	 	$insertLinksTrack->link_id = $record_id;
	    	 	$insertLinksTrack->ip_address = request()->ip();
	    	 	$insertLinksTrack->save();
	    	 	return redirect()->away($long_url);	
    		}
    		else{
    			abort(404);
    		}
    	}
    	else{
    		//$links = Link::all()->withCount('linkstracks');
    		$links = Link::withCount('tracks')->get();;
    		return view('links.index', compact('links'));
    	}
    }

    public function store()
    {
       	request()->validate([
       			'long_url' => ['required','url','unique:links','min:10'],
       			'email' => ['required','email','regex:/(.*)@sunway\.com.my|sunway\.edu.my/i']
       		]
       	);
       	//request()->validate(['email' => ['required','email','regex:/(.*)@sunway\.com.my/i']]);
       	$uri_id = $this->generateRandomString();
       	$unique_str = Link::where('uri_id', $uri_id)->count();
       	$links = new Link();
       	if($unique_str == 0){
       		$links->uri_id = $uri_id;
       	}
       	else{
       		$links->uri_id = $this->generateRandomString();
       	}
    	$links->long_url = request('long_url');
    	$links->email = request('email');
    	//$links->uri_id = str_random(5);
    	$links->save();
		return redirect('/links'); 
    }

    public function uri_random_strings()
    {
    	return str_random(5);
    }

    public function generateRandomString($length = 5) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
}
