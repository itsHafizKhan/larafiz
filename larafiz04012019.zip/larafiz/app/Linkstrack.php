<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Linkstrack extends Model
{
    //
}
