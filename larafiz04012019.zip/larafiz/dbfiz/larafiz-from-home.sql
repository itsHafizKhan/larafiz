-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 30, 2018 at 01:34 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `larafiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
CREATE TABLE IF NOT EXISTS `links` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uri_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `uri_id`, `long_url`, `email`, `created_at`, `updated_at`) VALUES
(1, 'FBnZD', 'https://stackoverflow.com/questions/23059918/laravel-get-base-url', 'apisz_sparrow@sunway.com.my', '2018-12-30 12:32:21', '2018-12-30 12:32:21'),
(2, 'sKvpp', 'https://laracasts.com/discuss/channels/requests/multiple-validation-rules-of-the-same-type', 'test@sunway.edu.my', '2018-12-30 12:32:49', '2018-12-30 12:32:49'),
(3, 'wjiJA', 'https://stackoverflow.com/questions/17861412/calling-other-function-in-the-same-controller', 'apisz_sparrow@sunway.com.my', '2018-12-30 13:11:25', '2018-12-30 13:11:25'),
(4, 'BXpYA', 'https://www.foxsportsasia.com/football/premier-league/1008389/top-6-premier-league-clubs-with-highest-percentage-of-big-chances-missed/', 'mhafiztk@sunway.com.my', '2018-12-30 13:23:14', '2018-12-30 13:23:14');

-- --------------------------------------------------------

--
-- Table structure for table `linkstracks`
--

DROP TABLE IF EXISTS `linkstracks`;
CREATE TABLE IF NOT EXISTS `linkstracks` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `link_id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `linkstracks`
--

INSERT INTO `linkstracks` (`id`, `link_id`, `ip_address`, `created_at`, `updated_at`) VALUES
(1, 1, '127.0.0.1', '2018-12-30 12:33:38', '2018-12-30 12:33:38'),
(2, 2, '127.0.0.1', '2018-12-30 12:33:41', '2018-12-30 12:33:41'),
(3, 2, '127.0.0.1', '2018-12-30 12:45:57', '2018-12-30 12:45:57'),
(4, 1, '127.0.0.1', '2018-12-30 13:07:09', '2018-12-30 13:07:09'),
(5, 2, '127.0.0.1', '2018-12-30 13:07:25', '2018-12-30 13:07:25'),
(6, 1, '127.0.0.1', '2018-12-30 13:09:50', '2018-12-30 13:09:50'),
(7, 2, '127.0.0.1', '2018-12-30 13:09:53', '2018-12-30 13:09:53'),
(8, 1, '127.0.0.1', '2018-12-30 13:10:12', '2018-12-30 13:10:12'),
(9, 3, '127.0.0.1', '2018-12-30 13:11:33', '2018-12-30 13:11:33'),
(10, 1, '127.0.0.1', '2018-12-30 13:17:39', '2018-12-30 13:17:39'),
(11, 3, '127.0.0.1', '2018-12-30 13:20:54', '2018-12-30 13:20:54'),
(12, 4, '127.0.0.1', '2018-12-30 13:30:26', '2018-12-30 13:30:26');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_12_26_095405_create_projects_table', 1),
(4, '2018_12_28_174532_create_tasks_table', 2),
(6, '2018_12_30_053209_create_links_table', 3),
(9, '2018_12_30_062217_create_links_track_table', 4),
(11, '2018_12_30_195506_add_email_to_links', 5);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `title`, `description`, `created_at`, `updated_at`) VALUES
(7, 'This is the Title of New Project', 'Lorom Ipsum is the desc', '2018-12-28 07:29:56', '2018-12-28 07:30:21'),
(6, 'Test uppp', '123', '2018-12-27 10:54:40', '2018-12-28 06:59:57'),
(3, 'P1 Updated New', 'UPDATED::Pq descr', '2018-12-27 02:54:49', '2018-12-27 10:47:46'),
(5, 'New Project Edited', 'Testing', '2018-12-27 10:45:54', '2018-12-27 10:46:01'),
(8, 'New Project TASCC', 'Hafiz Testing New eidted', '2018-12-28 07:37:10', '2018-12-28 07:37:24'),
(9, 'Tes', 'as', '2018-12-28 08:19:58', '2018-12-28 08:19:58'),
(11, 'Test New', '\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\"', '2018-12-28 08:31:23', '2018-12-28 08:31:23'),
(12, 'Hafiz Created before go home-edited at home', 'Wioilaskj apsido iaisjdpoaisjd', '2018-12-28 10:23:37', '2018-12-29 21:07:42');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `project_id` int(10) UNSIGNED NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `project_id`, `description`, `completed`, `created_at`, `updated_at`) VALUES
(1, 3, 'Testing Task', 0, '2018-12-28 09:56:13', '2018-12-28 09:56:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
