@extends('layouts.admin')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                
                    <div class="row">
                        <div class="col-md-6 text-left"><h5>{{ __('Users') }}</h5></div>
                        <div class="col-md-6 text-right"><a href="{{ URL::to('admin/users/create') }}" class="btn btn-danger">Add New User</a></div>
                    </div> 
            </div>
                @if (session('success'))
                    <div class="alert alert-success">
                        {{ Session::get('success') }}    
                    </div>
                    
                @endif
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($users as $user)
                            <tr>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }}</td>
                                <td>{{ \Carbon\Carbon::parse($user->created_at)->format('d-m-Y') }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
