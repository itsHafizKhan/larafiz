@extends('layout')

@section('content')

	<h1 class="title">Create New Shortened URL</h1>

	<form method="POST" action="/links/">
		@csrf

		<div class="columns">
			<div class="column">
				<div class="field">
					<label class="label">
						Long URL
					</label>
					<div class="control">
						<input class="input" type="text" name="long_url" placeholder="Long URL" value="{{ old('long_url') }}"></input>	
					</div>
				</div>
			</div>
			<div class="column">
				<div class="field">
					<label class="label">
						Your Email Address
					</label>
					<div class="control">
						<input class="input" type="text" name="email" placeholder="Email" value="{{ old('email') }}"></input>	
					</div>
				</div>
			</div>
		</div>
		<div class="columns">
			<div class="column">
				<div class="field">
					<label></label>
					<div class="control">
						<button class="button is-link" type="submit">Shortened My URL</button>
					</div>
				</div>
			</div>
		</div>



		@if ($errors->any())
            <div class="notification is-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

	</form>
	@if ($links->isNotEmpty())
	<div class="columns container">
		<div class="column">
			<table class="table is-bordered">
				<thead>
					<tr>
						<th>Shortened Links</th>
						<th>Original Links</th>
						<th>Owners</th>
						<th>No of Clicks</th>
					</tr>
				</thead>
				<tbody>
					@foreach ($links as $link)
						<tr>
							<td><a href="/links/{{ $link->uri_id }}" target="_blank">{{ url('/links/'.$link->uri_id) }}</a></td>
							<td>{{ $link->long_url }}</td>
							<td>{{ $link->email }}</td>
							<td>{{ $link->tracks_count }}</td>
						</tr>
					@endforeach
				</tbody>
			</table>
		</div>	
	</div>	
	
	@endif


@endsection