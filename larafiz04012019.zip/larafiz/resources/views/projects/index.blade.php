<!DOCTYPE html>
<html>
<head>
	<title>Projects</title>
</head>
<body>
	<h1>Projects</h1>
		<ul>
			@foreach ($projects as $projects)
				<li>
					<a href="/projects/{{ $projects->id }}">
						{{ $projects->title }}
					</a>
					
				</li>
			@endforeach
		</ul>

</body>
</html>