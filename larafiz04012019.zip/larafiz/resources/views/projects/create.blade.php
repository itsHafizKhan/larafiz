@extends('layout')

@section('content')

	<h1 class="title">Create Project</h1>

	<form method="POST" action="/projects/">
		@csrf

		<div class="field">
			<label class="label">
				Title
			</label>
			<div class="control">
				<input class="input" type="text" name="title" placeholder="Title" value="{{ old('title') }}"></input>	
			</div>
		</div>


		<div class="field">
			<label class="label">
				Description
			</label>
			<div class="control">
				<textarea class="textarea" name="description">{{ old('description') }}</textarea>
			</div>
		</div>

		<div class="field">
			<div class="control">
				<button class="button is-link" type="submit">Create Project</button>
			</div>
		</div>
		@include('errors')

	</form>

@endsection